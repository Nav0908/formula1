# Databricks notebook source
def mount_container(storage_name, container):
    dbutils.secrets.list("formula1-scope")
    client_id = dbutils.secrets.get(scope="formula1-scope", key="formula1-app-client-id")
    tenant_id = dbutils.secrets.get(scope="formula1-scope", key="formula1-app-tenant-id")
    client_secret = dbutils.secrets.get(scope="formula1-scope", key="formula1-app-client-secret")

    configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": client_secret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    
     # Unmount the mount point if it already exists
    if any(mount.mountPoint == f"/mnt/{storage_name}/{container}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storage_name}/{container}")

    dbutils.fs.mount(
    source = f"abfss://{container}@{storage_name}.dfs.core.windows.net/",
    mount_point = f"/mnt/{storage_name}/{container}",
    extra_configs = configs)    

    display(dbutils.fs.mounts())

# COMMAND ----------

mount_container('formula1datalake124', 'raw')

# COMMAND ----------

mount_container('formula1datalake124', 'presentation')

# COMMAND ----------

mount_container('formula1datalake124', 'processed')

# COMMAND ----------



# COMMAND ----------

mount_