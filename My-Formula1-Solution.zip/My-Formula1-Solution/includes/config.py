# Databricks notebook source
raw_folder_path = '/mnt/formula1datalake124/raw'
processed_folder_path = '/mnt/formula1datalake124/processed'
presentation_folder_path = '/mnt/formula1datalake124/presentation'

# COMMAND ----------

