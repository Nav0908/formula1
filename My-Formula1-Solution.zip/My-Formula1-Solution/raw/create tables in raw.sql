-- Databricks notebook source
-- MAGIC %md
-- MAGIC

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_raw 
LOCATION "/mnt/formula1datalake124/raw"

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.constructors;
CREATE TABLE IF NOT EXISTS f1_raw.constructors(
constructorId INT,
constructorRef STRING,
name STRING,
nationality STRING,
url STRING)
USING json
OPTIONS(path "/mnt/formula1dl/raw/constructors.json")

-- COMMAND ----------

desc  extended f1_raw.constructors

-- COMMAND ----------

select * from f1_raw.constructors