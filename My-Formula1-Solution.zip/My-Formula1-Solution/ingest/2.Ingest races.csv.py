# Databricks notebook source
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, DateType


# COMMAND ----------

races_schema= StructType(fields = [StructField('raceId', IntegerType(), False),
                                    StructField('year', StringType(), True),
                                    StructField('round', StringType(), True),
                                    StructField('circuitId', IntegerType(), True),
                                    StructField('name', StringType(), True),
                                    StructField('date', DateType(), True),
                                    StructField('time', StringType(), True),
                                    StructField('url', StringType(), True)
                                    ])

# COMMAND ----------

races_df = spark.read \
    .option('header', True)\
    .schema(races_schema)\
    .csv('/mnt/formula1datalake124/raw/races.csv')

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, to_timestamp, concat, lit, col

# COMMAND ----------

races_added_cols_df = races_df.withColumns({'ingestion_date': current_timestamp(),
                                           'race_timestamp' : to_timestamp(concat(col('date'), lit(' ' ), col('time')), 'yyyy-MM-dd HH:mm:ss')})

# COMMAND ----------

races_renamed_df = races_added_cols_df.withColumnsRenamed({'raceId':'race_id',
                                                           'year': 'race_year',
                                                           'circuitId':'circuit_id',
                                                           'name': 'race_name'})

# COMMAND ----------

races_final_df = races_renamed_df.select(col('race_id'), col('race_year'), col('round'), col('circuit_id'), col('race_name'), col('race_timestamp'),col('ingestion_date') )

# COMMAND ----------

races_final_df.write.mode("overwrite").partitionBy('race_year').format("parquet").saveAsTable("f1_processed.races")