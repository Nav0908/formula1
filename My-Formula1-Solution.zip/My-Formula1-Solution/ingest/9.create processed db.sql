-- Databricks notebook source
create database if not exists f1_processed
location '/mnt/formula1datalake124/processed'

-- COMMAND ----------

show tables in f1_processed