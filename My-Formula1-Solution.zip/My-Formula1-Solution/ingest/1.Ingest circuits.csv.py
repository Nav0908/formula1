# Databricks notebook source
# MAGIC %run "../includes/config"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType 

# COMMAND ----------

circuits_schema = StructType(fields=[StructField("circuitId", IntegerType(), False),
                                     StructField("circuitRef", StringType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("location", StringType(), True),
                                     StructField("country", StringType(), True),
                                     StructField("lat", DoubleType(), True),
                                     StructField("lng", DoubleType(), True),
                                     StructField("alt", IntegerType(), True),
                                     StructField("url", StringType(), True)
])

# COMMAND ----------

circuits_df = spark.read \
.option("header", True) \
.schema(circuits_schema) \
.csv(f"{raw_folder_path}/circuits.csv")

# COMMAND ----------

from pyspark.sql.functions import col
circuits_selected_col_df = circuits_df.select(col("circuitId"), col("circuitRef"), col("name"), col("location"), col("lat"), col("lng"), col("alt"))

# COMMAND ----------

circuits_renamed_df = circuits_selected_col_df.withColumnRenamed("name", "circuit_name")\
    .withColumnRenamed("circuitId", "circuit_id")\
    .withColumnsRenamed({'circuitRef': 'circuit_ref', 'lat':'latitude', 'lng': 'longitude', 'alt':'altitude'})



# COMMAND ----------

circuits_final_df= add_ingestion_date(circuits_renamed_df)


# COMMAND ----------

circuits_final_df.write.mode('overwrite').format('parquet').saveAsTable('f1_processed.circuits')