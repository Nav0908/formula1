# Databricks notebook source
from pyspark.sql.types import StructField, StructType, IntegerType, StringType

# COMMAND ----------

constructors_schema = StructType(fields=[StructField('constructorId', IntegerType(), False),
                                         StructField('constructorRef', StringType(), True),
                                         StructField('name', StringType(), True),
                                         StructField('nationality', StringType(), True),
                                         StructField('url', StringType(), True)
                                         ])

# COMMAND ----------

constructors_df = spark.read\
                .schema(constructors_schema)\
                .json('/mnt/formula1datalake124/raw/constructors.json')

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

constructors_updated_df = constructors_df.withColumnsRenamed({'constructorId': 'constructor_id',
                        'constructorRef': 'constructor_ref', 'name': 'constructor_name'})\
                        .withColumn('ingestion_date', current_timestamp())

# COMMAND ----------

constructors_final_df = constructors_updated_df.drop('url')

# COMMAND ----------

constructors_final_df.write.mode('overwrite').format('parquet').saveAsTable('f1_processed.constructors')