# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

qualifying_schema= StructType(fields= [StructField("qualifyId", IntegerType(), False),
                                       StructField('raceId', IntegerType(), True),
                                       StructField('driverId', IntegerType(), True),
                                       StructField('constructorId', IntegerType(), True),
                                       StructField('number', IntegerType(), True),
                                       StructField('position', IntegerType(), True),
                                       StructField('q1', StringType(), True),
                                       StructField('q2', StringType(), True),
                                       StructField('q3', StringType(), True),
   
])

# COMMAND ----------

qualifying_df = spark.read\
            .schema(qualifying_schema)\
            .option('multiLine', True)\
            .json('/mnt/formula1datalake124/raw/qualifying')

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

qualifying_final_df = qualifying_df.withColumnsRenamed({'qualifyId': 'qualify_id',
                                                        'raceId': 'race_id',
                                                        'driverId': 'driver_id',
                                                        'constructorId': 'constructor_id'
                                                        })\
                        .withColumn('ingestion_date', current_timestamp())

# COMMAND ----------

qualifying_final_df.write.mode('overwrite').format('parquet').saveAsTable('f1_processed.qualifying')

# COMMAND ----------

