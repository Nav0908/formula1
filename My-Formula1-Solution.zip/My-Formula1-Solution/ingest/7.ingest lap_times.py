# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

lap_times_schema = StructType(fields=[ StructField('raceId', IntegerType(), False),
                                      StructField('driverId', IntegerType(), True),
                                      StructField('lap', IntegerType(), True),
                                      StructField('position', IntegerType(), True),
                                      StructField('time', DateType(), True),
                                      StructField('milliseconds', IntegerType(), True),

])

# COMMAND ----------

lap_times_df = spark.read\
            .schema(lap_times_schema)\
            .csv('/mnt/formula1datalake124/raw/lap_times')

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

lap_times_final_df = lap_times_df.withColumnsRenamed({'raceId':'race_id', 'driverId':'driver_id'})\
.withColumn('ingestion_date', current_timestamp())

# COMMAND ----------

lap_times_final_df.write.mode('overwrite').format('parquet').saveAsTable('f1_processed.lap_times')