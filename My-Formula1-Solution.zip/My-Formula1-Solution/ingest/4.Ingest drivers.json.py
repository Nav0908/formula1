# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

driver_names_schema = StructType(fields=[StructField('forename', StringType(), True),
                                         StructField('surname', StringType(), True)

])

# COMMAND ----------

drivers_schema = StructType(fields =[StructField('driverId', IntegerType(), False),
                                      StructField('driverRef', StringType(), True),
                                      StructField('number', IntegerType(), True),
                                      StructField('code', StringType(), True),
                                      StructField('name',driver_names_schema),
                                      StructField('dob', DateType(), True),
                                      StructField('nationality', StringType(), True),
                                      StructField('url', StringType(), True)
                                    ])

# COMMAND ----------

drivers_df = spark.read\
            .schema(drivers_schema)\
            .json('/mnt/formula1datalake124/raw/drivers.json')
            

# COMMAND ----------

from pyspark.sql.functions import concat, col, current_timestamp, lit

# COMMAND ----------

driver_renamed_df = drivers_df.withColumnsRenamed({'driverId':'driver_id',
                                                'driverRef':'driver_ref'})\
                            .withColumns({'name': concat(col('name.forename'), lit(' '), col('name.surname')),
                            'ingestion_date': current_timestamp()})
                                                

# COMMAND ----------

driver_renamed_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.drivers")