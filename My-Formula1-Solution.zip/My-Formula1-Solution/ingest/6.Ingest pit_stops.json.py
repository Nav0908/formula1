# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

pitstops_schema = StructType(fields=[StructField("raceId", IntegerType(),False),
                                    StructField('driverId', IntegerType(), True),
                                    StructField('stop', StringType(), True),
                                    StructField('lap', IntegerType(), True),
                                    StructField('time', StringType(), True),
                                    StructField('duration', StringType(), True),
                                    StructField('milliseconds', IntegerType(), True)

])

# COMMAND ----------

pitstops_df = spark.read\
            .schema(pitstops_schema)\
            .option('multiLine', True)\
            .json('/mnt/formula1datalake124/raw/pit_stops.json')\
            

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

pitstops_final_df =pitstops_df.withColumnsRenamed({'raceId':'race_id', 'driverId': 'driver_id'})\
                .withColumn('ingestion_date', current_timestamp())

# COMMAND ----------

pitstops_final_df.write.mode('overwrite').format('parquet').saveAsTable('f1_processed.pit_stops')