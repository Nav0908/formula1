-- Databricks notebook source
drop table if exists f1_presentation.dominant_drivers

-- COMMAND ----------

create table if not exists f1_presentation.dominant_drivers
USING PARQUET
AS
select rank() over (order by count_if(position=1) desc) as driver_rank,
  driver_name, team_name,race_year,
  count_if(position = 1)as wins, count(1) as race_count,
  round( avg(calculated_points),3) as avg_points,
  calculated_points 
from f1_presentation.calculated_race_results
group by driver_name, team_name,race_year, calculated_points
order by wins desc, avg_points desc
  



-- COMMAND ----------

create or replace view max_win_drivers as
 select * from f1_presentation.dominant_drivers
  where wins >6

-- COMMAND ----------

select * from max_win_drivers

-- COMMAND ----------

create or replace view max_points_drivers
as
select * from f1_presentation.dominant_drivers 
where avg_points > 6 and race_count > 7

-- COMMAND ----------

select * from max_points_drivers




-- COMMAND ----------

select year(curdate())

-- COMMAND ----------

select driver_name, sum(dominant_drivers.calculated_points) from f1_presentation.dominant_drivers
group by dominant_drivers.driver_name 
order by sum(calculated_points) desc limit 10



-- COMMAND ----------

select * from f1_presentation.dominant_drivers where race_year =2020