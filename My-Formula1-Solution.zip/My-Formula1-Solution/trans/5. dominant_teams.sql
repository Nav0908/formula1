-- Databricks notebook source
CREATE TABLE IF NOT EXISTS f1_presentation.dominant_teams
USING PARQUET
AS
select team_name, count_if(position=1) as wins,
  round(avg(calculated_points)) as avg_points,
  count(1) as total_races
from f1_presentation.calculated_race_results
group by team_name
having total_races >100
order by wins desc, avg_points desc


-- COMMAND ----------

select 