-- Databricks notebook source
create database if not exists f1_presentation
location '/mnt/formula1datalake124/presentation'

-- COMMAND ----------

show tables in f1_presentation

-- COMMAND ----------

desc table extended f1_presentation.race_results