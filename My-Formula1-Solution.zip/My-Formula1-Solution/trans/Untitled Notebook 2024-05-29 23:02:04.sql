-- Databricks notebook source
create table A
(id INT);

-- COMMAND ----------

insert into A values(1),(2),(3),(4),(5);

-- COMMAND ----------

create table B(id int);

-- COMMAND ----------

insert into b values (1),(2),(3);

-- COMMAND ----------

select a.id from a left join b on a.id=b.id
where b.id is null
