# Databricks notebook source
# MAGIC %run "../includes/config"

# COMMAND ----------

races_df= spark.read.parquet(f'{processed_folder_path}/races')\
        .withColumnRenamed('race_timestamp', 'race_date')

# COMMAND ----------

circuits_df=spark.read.parquet(f'{processed_folder_path}/circuits')\
                    .withColumnRenamed('location', 'circuit_location')

# COMMAND ----------

drivers_df=spark.read.parquet(f'{processed_folder_path}/drivers')\
                .withColumnsRenamed({'number':'driver_number', 'code':'driver_code', 'name':'driver_name', 'nationality':'driver_nationality'})
            

# COMMAND ----------

constructors_df=spark.read.parquet(f'{processed_folder_path}/constructors')\
                .withColumnRenamed('constructor_name', 'team')

# COMMAND ----------

results_df = spark.read.parquet(f'{processed_folder_path}/results')\
            .withColumnRenamed('time', 'race_time')

# COMMAND ----------

race_circuits_df = circuits_df.join(races_df, circuits_df.circuit_id == races_df.circuit_id, 'inner')\
.select(races_df.race_id, races_df.race_name, races_df.race_year, races_df.race_date, circuits_df.circuit_location)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_results_df=race_circuits_df.join(results_df, race_circuits_df.race_id==results_df.        race_id,'inner')\
        .join(drivers_df, results_df.driver_id == drivers_df.driver_id, 'inner')\
        .join(constructors_df, results_df.constructor_id==constructors_df.constructor_id, 'inner')\
        .select(races_df.race_id,races_df.race_year, races_df.race_name, races_df.race_date,circuits_df.circuit_location,drivers_df.driver_name, drivers_df.driver_number, drivers_df.driver_nationality,
                constructors_df.team, results_df.grid, results_df.fastest_lap, results_df.race_time, results_df.points)\
        .withColumn('created_date', current_timestamp())

# COMMAND ----------

    display(final_results_df.filter("race_year == 2020 and race_name == 'Abu Dhabi Grand Prix'").orderBy(final_results_df.points.desc()))


# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS f1_presentation
# MAGIC LOCATION '/mnt/formula1datalake124/presentation'

# COMMAND ----------

final_results_df.write.mode('overwrite').format('parquet').saveAsTable('f1_presentation.race_results')

# COMMAND ----------

# MAGIC %sql 
# MAGIC select count(*) from f1_presentation.race_results